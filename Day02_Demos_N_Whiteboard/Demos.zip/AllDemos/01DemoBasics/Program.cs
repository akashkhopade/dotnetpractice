﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01DemoBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Sample Old Code
            //for (int k = 0; k < 10; k++)
            //{
            //    if (k==5)
            //    {
            //        break;
            //    }
            //    Console.WriteLine(k);
            //}
            #endregion

            Person p1 = new Person();
            p1.Name = "Mahesh";
            Console.WriteLine(p1.Name);
            Console.ReadLine();
        }
    }
    class Maths
    {
        #region Methods
        public int Add(int x, int y)
        {
            return x + y;
        }

        public int Sub(int x, int y)
        {
            return x - y;
        }
        #endregion
    }
    class Person
    {
        #region Private Members
        private int _No;
        private string _Name;
        private string _Address;
        #endregion

        #region Constructors
        public Person()
        {
            _No = 0;
            _Name = "";
            _Address = "";
        }
        #endregion

        #region Getter Setters
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public int No
        {
            get { return _No; }
            set { _No = value; }
        }
        #endregion


    }

    #region Old way of creating Person Class
    //class Person
    //{
    //    #region Private Member Declaration
    //    private int _No;
    //    private string _Name;
    //    private string _Address;
    //    #endregion

    //    #region Constructors
    //    public Person()
    //    {
    //        _No = 0;
    //        _Name = "";
    //        _Address = "";
    //    }
    //    #endregion

    //    #region Getter Setters
    //    public int Get_No()
    //    {
    //        return _No;
    //    }
    //    public void Set_No(int no)
    //    {
    //        _No = no;
    //    }
    //    public string Get_Name()
    //    {
    //        return _Name;
    //    }
    //    public void Set_Name(string name)
    //    {
    //        _Name = name;
    //    }
    //    public string Get_Address()
    //    {
    //        return _Address;
    //    }
    //    public void Set_Address(string address)
    //    {
    //        _Address = address;
    //    }
    //    #endregion
    //}
    #endregion
}
