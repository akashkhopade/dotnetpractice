﻿using System;

//namespace Test
namespace _00Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            _00Demo.Maths obj = new _00Demo.Maths();
            int result = obj.Add(10, 20);
            Console.WriteLine(result);

            X.Maths obj2 = new X.Maths();
            int result2 = obj2.Add(10, 20, 30);
            Console.WriteLine(result2);

            Console.ReadLine();
        }
    }
}


//namespace Test
//{
//    class Sample
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Demo of main method");
//            Console.ReadLine();
//        }
//    }
//}