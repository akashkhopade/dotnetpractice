﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02DemoBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Enter X value");
                int x = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Y value");
                int y = Convert.ToInt32(Console.ReadLine());

                int result = 0;

                Console.WriteLine("Enter Your Choice:");
                Console.WriteLine("1: Add, 2: Sub, 3: Exit");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        result = x + y;
                        Console.WriteLine(result);
                        break;
                    case 2:
                        result = x - y;
                        Console.WriteLine(result);
                        break;
                    case 3:
                        break;
                    default:
                        Console.WriteLine("Wrong Choice!!");
                        break;
                }

                Console.WriteLine("Do you want to continue? yes / no");
                string choiceToContinue = Console.ReadLine();
                if (choiceToContinue == "no")
                {
                    break;
                }
            }
        }
    }
}
