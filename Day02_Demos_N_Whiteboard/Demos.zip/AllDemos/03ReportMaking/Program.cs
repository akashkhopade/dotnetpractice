﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03ReportMaking
{
    class Program
    {
        static void Main(string[] args)
        {
            ReportFactory reportFactory = new ReportFactory();

            Console.WriteLine("Which report type you need?");
            Console.WriteLine("1: PDF, 2: DOCX, 3: Excel, 4: TXT");
            int choice = Convert.ToInt32(Console.ReadLine());

            Report report = reportFactory.GetSomeReport(choice);
            if (report!=null)
            {
                report.Generate();
            }
            else
            {
                Console.WriteLine("Invalid Choice!");
            }
          
            Console.ReadLine();
        }
    }
    public class ReportFactory
    {
        public Report GetSomeReport(int choice)
        {
            if (choice == 1)
            {
                return new PDF();
            }
            else if (choice ==2)
            {
                return new DOCX();
            }
            else if (choice == 3)
            {
                return new Excel();
            }
            else if (choice == 4)
            {
                return new TXT();
            }
            else
            {
                return null;
            }
        }
    }
    public class Maths
    {
        int Add()
        {
            return 0;
        }
        int Sub()
        {
            return 0;
        }

    }
    public abstract class Report
    {
        protected abstract void Create();
        protected abstract void Parse();
        protected abstract void Validate();
        protected abstract void Save();
       
        public virtual void Generate()
        {
            Create();
            Parse();
            Validate();
            Save();
        }
    }
    
    public abstract class SpecialReport: Report
    {
        protected abstract void ReValidate();

        public override void Generate()
        {
            Create();
            Parse();
            Validate();
            ReValidate();
            Save();
        }
    }
    
    public class PDF: Report
    {
        protected override void Create()
        {
            //Below line is simulation of PDF Creation Code of 100 lines
            Console.WriteLine("PDF Created!");
        }
        protected override void Parse()
        {
            //Below line is simulation of PDF Parsing Code of 200 lines
            Console.WriteLine("PDF Data Parsed!");
        }
        protected override void Validate()
        {
            //Below line is simulation of PDF Validation Code of 300 lines
            Console.WriteLine("PDF Data Validated!");
        }

        protected override void Save()
        {
            //Below line is simulation of PDF Saving Code of 200 lines
            Console.WriteLine("PDF Saved!");
        }
      
    }
    public class DOCX : Report
    {
        protected override void Create()
        {
            //Below line is simulation of DOCX Creation Code of 100 lines
            Console.WriteLine("DOCX Created!");
        }
        protected override void Parse()
        {
            //Below line is simulation of DOCX Parsing Code of 200 lines
            Console.WriteLine("DOCX Data Parsed!");
        }
        protected override void Validate()
        {
            //Below line is simulation of DOCX Validation Code of 300 lines
            Console.WriteLine("DOCX Data Validated!");
        }
        protected override void Save()
        {
            //Below line is simulation of DOCX Saving Code of 200 lines
            Console.WriteLine("DOCX Saved!");
        }

    }
    public class Excel : Report
    {
        protected override void Create()
        {
            //Below line is simulation of Excel Creation Code of 100 lines
            Console.WriteLine("Excel Created!");
        }
        protected override void Parse()
        {
            //Below line is simulation of Excel Parsing Code of 200 lines
            Console.WriteLine("Excel Data Parsed!");
        }
        protected override void Validate()
        {
            //Below line is simulation of Excel Validation Code of 300 lines
            Console.WriteLine("Excel Data Validated!");
        }
        protected override void Save()
        {
            //Below line is simulation of Excel Saving Code of 200 lines
            Console.WriteLine("Excel Saved!");
        }
    }

    public class TXT : SpecialReport
    {
        protected override void Create()
        {
            //Below line is simulation of TXT Creation Code of 100 lines
            Console.WriteLine("TXT Created!");
        }
        protected override void Parse()
        {
            //Below line is simulation of TXT Parsing Code of 200 lines
            Console.WriteLine("TXT Data Parsed!");
        }
        protected override void Validate()
        {
            //Below line is simulation of TXT Validation Code of 300 lines
            Console.WriteLine("TXT Data Validated!");
        }
        protected override void ReValidate()
        {
            //Below line is simulation of TXT Validation Code of 300 lines
            Console.WriteLine("TXT Data Re - Validated!");
        }
        protected override void Save()
        {
            //Below line is simulation of TXT Saving Code of 200 lines
            Console.WriteLine("TXT Saved!");
        }
    }
}
